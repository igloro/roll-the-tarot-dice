# roll-the-tarot-dice
Roll astrology tarot 12 sided dices

Participation in game Jam: https://itch.io/jam/gmtk-jam-2022
Published on itch io: https://igloro.itch.io/